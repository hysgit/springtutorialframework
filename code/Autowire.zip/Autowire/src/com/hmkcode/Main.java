package com.hmkcode;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {

	public static ApplicationContext ctx;
	public static void main(String args[]){
		
		// Laod spring-config.xml file
		ctx = new ClassPathXmlApplicationContext("com/hmkcode/config/spring-config.xml");

	}
}
