package com.hmkcode.beans.shapes;

public class Circle  {

	//these variables (autowire & id) has nothing to do with spring autowire
	//just to be used in output
	private String autowire;
	private String id;
	
	public Circle(){		
	}

	public String getAutowire() {
		return autowire;
	}

	public void setAutowire(String autowire) {
		this.autowire = autowire;
	}
	
	public String getId(){
		return id;
	}
	public void setId(String id){
		this.id = id;
	}
	

}
