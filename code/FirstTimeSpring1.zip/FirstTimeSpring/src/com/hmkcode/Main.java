package com.hmkcode;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hmkcode.beans.Circle;
import com.hmkcode.beans.ShapePainter;

public class Main {

	public static void main(String args[]){
		
		// Laod spring-config.xml file
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/hmkcode/config/spring-config.xml");
		
		//get circle bean defined in spring-config.xml file
		Circle circle =(Circle)ctx.getBean("circle");
		ShapePainter sp = (ShapePainter) ctx.getBean("shapePainter");
		
		// use this to test scope="prototype"
		//circle =(Circle)ctx.getBean("circle");
		

		//do something with the bean
		
		//circle.draw();
		//circle.area();
	}
}
