package com.hmkcode.beans;

public interface Shape {
	void draw();
	void area();
}
