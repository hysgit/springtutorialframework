package com.hmkcode.vo;

public class UploadedFile {

	public int length;
	public byte[] bytes;
	public String name;
	public String type;
}
