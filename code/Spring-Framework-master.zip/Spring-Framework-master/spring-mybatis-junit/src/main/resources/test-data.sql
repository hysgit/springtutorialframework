INSERT INTO parent (parentName) VALUES ('parent-1')
INSERT INTO parent (parentName) VALUES ('parent-2')
INSERT INTO parent (parentName) VALUES ('parent-3')

INSERT INTO child (childName,parentId) VALUES ('child-1',1)
INSERT INTO child (childName,parentId) VALUES ('child-2',1)
INSERT INTO child (childName,parentId) VALUES ('child-3',2)

