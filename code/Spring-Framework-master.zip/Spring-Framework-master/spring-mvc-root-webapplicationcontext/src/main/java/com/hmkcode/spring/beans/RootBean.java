package com.hmkcode.spring.beans;

public class RootBean {

	@Override
	public String toString() {
		return "RootBean";
	}

	
}
